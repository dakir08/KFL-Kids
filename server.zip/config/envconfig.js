module.exports = {
  PORT: 1702 || process.env.PORT,
  JWTKEY: "I Love Duong Anh :P" || process.env.KFLToken,
  DB: "mongodb://localhost/KFL",
  DB_TEST: "mongodb://localhost/KFL_test"
};
