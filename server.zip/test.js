const {formatDate} = require("./modules/customfunction");


console.log(formatDate('12/07/2019'));
