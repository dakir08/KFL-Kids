PLEASE INSTALL NODEJS, MONGODB ON YOUR COMPUTER
"npm i"
"npm start" or "node app.js" or "nodemon app.js"
* PLEASE DO NOT ZIP THE "node_modules" folder, thanks :)